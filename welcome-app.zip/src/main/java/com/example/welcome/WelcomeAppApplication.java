package com.example.welcome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WelcomeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WelcomeAppApplication.class, args);
	}

}
