package com.example.welcome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelcomeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
